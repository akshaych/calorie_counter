package cis350.upenn.edu.easyfooddiary;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by haile on 3/24/2017.
 */

public class TrackerView extends TextView {

    public TrackerView(Context c) {
        super(c);
    }

    public TrackerView(Context c, AttributeSet a) {
        super(c, a);
    }
}
