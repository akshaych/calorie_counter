package cis350.upenn.edu.easyfooddiary;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by akshay on 4/7/17.
 */

public class NutritionView extends TextView {

    public NutritionView(Context c) {
        super(c);
    }

    public NutritionView(Context c, AttributeSet a) {
        super(c, a);
    }

}
