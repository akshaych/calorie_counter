package cis350.upenn.edu.easyfooddiary;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by akshay on 2/24/17.
 */

public class SignupView extends TextView {

    public SignupView(Context c) {
        super(c);
    }

    public SignupView(Context c, AttributeSet a) {
        super(c, a);
    }


}
